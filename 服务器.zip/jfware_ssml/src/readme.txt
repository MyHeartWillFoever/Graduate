
jfware说明:

1. spring3.2 springmvc3.2 mybatis3.1.1整合应用

2. 添加Lucene4.4.0

3. 数据库表在db.sql中

步骤:

目录准备:
SystemContent中的目录:

PDF转换成txt目录:
D:\lucene\datadir\pdftxtdir

索引存放目录:
D:\lucene\luceneindex

xpdf目录:
D:\lucene\xpdf

文档初始化
http://localhost:8080/jfware_ssml/fileIndex.do

文档搜索
http://localhost:8080/jfware_ssml