package cn.ssms.controller;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.boge.AnswersWithBLOBs;
import com.boge.QuestionsWithBLOBs;
import com.boge.UsersWithBLOBs;

import cn.ssms.search.AdvanceGetSearchResult;
import cn.ssms.search.DocumentEntity;
import cn.ssms.util.PageNumBean;

/**
 * 
 *
 */
@Controller
public class AdvanceSearchController {
	/**
	 * 
	 * @throws Exception
	 */
	@RequestMapping("advanceSearchIndex")
	public ModelAndView advanceSearchIndex(HttpServletRequest request)
			throws Exception {
		System.out.println("AdvanceSearchController.advanceSearchIndex");//打印只是为了查看前后端的对应
		int pagetype = Integer.parseInt(request.getParameter("pagetype"));
		String filetype = request.getParameter("filetype");//用户选择的是知乎回答、知乎提问还是知乎用户
//		String qtype = request.getParameter("qtype");
		String qtype = "qtype";
		String fieldname = request.getParameter("fieldname");//用户输入的关键字
		int totalpage = Integer.parseInt(request.getParameter("totalpage"));
		fieldname = new String(fieldname.getBytes("ISO-8859-1"), "UTF-8");//编码格式转换

		int currentNum = 1;
		AdvanceGetSearchResult gsr = new AdvanceGetSearchResult(pagetype,
				filetype, qtype, fieldname, totalpage);//初始化高级搜索类
		List<AnswersWithBLOBs> list = new ArrayList<AnswersWithBLOBs>();//承载搜索回答的返回结果
		List<QuestionsWithBLOBs> list2 = new ArrayList<QuestionsWithBLOBs>();//承载搜索提问的返回结果
		List<UsersWithBLOBs> list3 = new ArrayList<UsersWithBLOBs>();//承载搜索用户的返回结果
		int recordCount = 0;//记录长度
		if ("answer".equals(filetype)) {//知乎回答
			recordCount = gsr.getScoreDocs().length;
		}else if ("question".equals(filetype)) {//知乎提问
			recordCount = gsr.getScoreDocs2().length;
		}else {//知乎用户
			recordCount = gsr.getScoreDocs3().length;
		}
		PageNumBean pageBean = null;
		pageBean = (PageNumBean) request.getAttribute("pageNumBean");
		if (pageBean == null) {
			pageBean = new PageNumBean(1, recordCount, pagetype, pagetype);
			request.setAttribute("pageNumBean", pageBean);
		}
		Integer downPageNum = currentNum + 1;//下一页
		if (downPageNum > pageBean.getPageCount())
			downPageNum = null;//若下一页超过总的页数，则定义为null
		Integer upPageNum = currentNum - 1;//上一页
		if (upPageNum == 0)
			upPageNum = null;//若上一页的页数为0，则将upPageNum赋值为null
		pageBean.setUpPageNum(upPageNum);
		pageBean.setDownPageNum(downPageNum);
		pageBean.setCurrentNum(currentNum);
		request.setAttribute("pageNumBean", pageBean);
		request.setAttribute("sk", fieldname);
		request.setAttribute("sk1", URLEncoder.encode(fieldname, "UTF-8"));
		System.out.println(filetype);
		if ("answer".equals(filetype)) {//若用户选择的是知乎回答，则会将结果展示在result.jsp页面上
			System.out.println("one");
			list = gsr.getResult(1);
			return new ModelAndView("result")
			.addObject("pageUrl", "searchIndex.do?page=")
			.addObject("rsize", recordCount).addObject("rlist", list);
		} else if ("question".equals(filetype)) {//若用户选择的是知乎提问，则会将结果展示在result2.jsp页面上
			System.out.println("two");
			list2 = gsr.getResult2(1);
			System.out.println("list2.size() "+list2.size());
			System.out.println("recordCount "+recordCount);
			return new ModelAndView("result2")
			.addObject("pageUrl", "searchIndex.do?page=")
			.addObject("rsize", recordCount).addObject("rlist", list2);
		} else {//若用户选择的是知乎用户，则会将结果展示在result3.jsp页面上
			System.out.println("three");
			list3 = gsr.getResult3(1);
			return new ModelAndView("result3")
			.addObject("pageUrl", "searchIndex.do?page=")
			.addObject("rsize", recordCount).addObject("rlist", list3);
		}
	}
}
