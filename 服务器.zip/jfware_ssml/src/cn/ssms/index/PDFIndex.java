package cn.ssms.index;

import java.io.File;

import javax.servlet.http.HttpServletRequest;

import net.paoding.analysis.analyzer.PaodingAnalyzer;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cn.ssms.model.DocRecord;
import cn.ssms.pdf.XpdfParser;
import cn.ssms.service.DocRecordService;
import cn.ssms.util.SystemConstant;

/**
 * 创建PDF文档索引
 */
@Service("pdfIndex")
public class PDFIndex {
	@Autowired
	private DocRecordService docRecordService;
	
	/**
	 * 
	 * @throws Exception
	 */
	public void createPDFIndex(HttpServletRequest request) throws Exception {

		XpdfParser xpdfp = new XpdfParser();

		String dataDir = SystemConstant.getRootRealPath("pdf", request);
		//System.out.println("path" + dataDir);

		String indexDir = SystemConstant.indexDir;
		String txtContents = "";
		File[] files = new File(dataDir).listFiles();
		System.out.println(files.length);
		Analyzer analyzer = new PaodingAnalyzer();
		Directory directory = FSDirectory.open(new File(indexDir));
		IndexWriterConfig iwc = new IndexWriterConfig(Version.LUCENE_44, analyzer);
		IndexWriter writer = new IndexWriter(directory, iwc);
		long ldate = docRecordService.getDocTopOne(".pdf");
		for (int i = 0; i < files.length; i++) {
			if (files[i].lastModified() > ldate) {

				try {
					txtContents = xpdfp.getPDFFileContent(files[i].getCanonicalPath());
				} catch (Exception e) {
					e.printStackTrace();
					if(writer != null){
						writer.close();
					}
				}
				DocRecord drec = new DocRecord();
				drec.setDocType(".pdf");
				drec.setLastModify(files[i].lastModified());
				drec.setFileName(files[i].getName());

				Document document = new Document();
				int id = docRecordService.createDoc(drec);
				int index = files[i].getName().indexOf(".pdf");

				document.add(new StringField("id", "" + id, Field.Store.YES));
				document.add(new StringField("type", "pdf", Field.Store.YES));
				document.add(new StringField("fileName", files[i].getName().substring(0, index), Field.Store.YES));
				document.add(new TextField("contents", txtContents, Field.Store.YES));
				writer.addDocument(document);
			}
		}
//		File file = new File(SystemConstant.PDFTxtdir);
		writer.close();
		directory.close();
	}

}
