package cn.ssms.index;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import net.paoding.analysis.analyzer.PaodingAnalyzer;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.springframework.stereotype.Service;
import com.boge.JdbcUtil;

/**
 * 初始化索引
 */
@Service("initIndex")
public class InitIndex {
	private static Connection conn = null;
	private static Statement stmt = null;
	private static ResultSet rs = null;
	/* 知乎答案 */
	private String searchDir = "E:\\Test\\Index";
	private String searchDir2 = "E:\\Test\\Index2";// 知乎提问
	private String searchDir3 = "E:\\Test\\Index3";// 知乎用户
	private static File indexFile = null;
	private static Analyzer analyzer = null;
	/** 索引页面缓冲 */
	private SimpleDateFormat formatter = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");

	public void init() throws Exception {
		conn = JdbcUtil.getConnection();
		if (conn == null) {
			throw new Exception("数据库连接失败！");
		}
		String sql_answers = "select * from answers";
		String sql_questions = "select * from questions";
		String sql_users = "select * from users";
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql_answers);
			this.createIndex(rs); // 给数据库创建索引,此处执行一次，不要每次运行都创建索引，以后数据有更新可以后台调用更新索引

			rs = stmt.executeQuery(sql_questions);
			this.createIndex2(rs);

			rs = stmt.executeQuery(sql_users);
			this.createIndex3(rs);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("数据库查询sql出错！ ");
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
			if (conn != null)
				conn.close();
		}
	}

	/**
	 * 为数据库检索数据创建索引
	 * 
	 * @param rs
	 * @throws Exception
	 */
	private void createIndex(ResultSet rs) throws Exception {
		Directory directory = null;
		IndexWriter indexWriter = null;

		try {
			indexFile = new File(searchDir);
			if (!indexFile.exists()) {
				indexFile.mkdir();
			}
			directory = FSDirectory.open(indexFile);
			analyzer = new PaodingAnalyzer();

			IndexWriterConfig iwc = new IndexWriterConfig(Version.LUCENE_44,
					analyzer);
			indexWriter = new IndexWriter(directory, iwc);

			Document doc = null;
			while (rs.next()) {
				doc = new Document();
				Field id = new StringField("id", rs.getLong("id") + "",
						Field.Store.YES);
				Field answer = new TextField("answer", rs.getString("answer"),
						Field.Store.YES);
				Field question = new StringField("question",
						rs.getString("question"), Field.Store.YES);
				Field link = new StringField("link", rs.getString("link"),
						Field.Store.YES);
				Field time = new StringField("time", formatter.format(rs
						.getDate("time")), Field.Store.YES);

				doc.add(id);
				doc.add(answer);
				doc.add(question);
				doc.add(link);
				doc.add(time);
				indexWriter.addDocument(doc);
			}

			indexWriter.close();
			directory.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 为数据库检索数据创建索引
	 * 
	 * @param rs
	 * @throws Exception
	 */
	private void createIndex2(ResultSet rs) throws Exception {
		Directory directory = null;
		IndexWriter indexWriter = null;

		try {
			indexFile = new File(searchDir2);
			if (!indexFile.exists()) {
				indexFile.mkdir();
			}
			directory = FSDirectory.open(indexFile);
			analyzer = new PaodingAnalyzer();

			IndexWriterConfig iwc = new IndexWriterConfig(Version.LUCENE_44,
					analyzer);
			indexWriter = new IndexWriter(directory, iwc);

			Document doc = null;
			while (rs.next()) {
				doc = new Document();
				Field id = new StringField("id", rs.getLong("id") + "",
						Field.Store.YES);
				Field detail = new TextField("detail", rs.getString("detail"),
						Field.Store.YES);
				Field question = new StringField("question",
						rs.getString("question"), Field.Store.YES);
				Field link = new StringField("link", rs.getString("link"),
						Field.Store.YES);
				Field time = new StringField("time", formatter.format(rs
						.getDate("time")), Field.Store.YES);

				doc.add(id);
				doc.add(question);
				doc.add(detail);
				doc.add(link);
				doc.add(time);
				indexWriter.addDocument(doc);
			}

			indexWriter.close();
			directory.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 为数据库检索数据创建索引
	 * 
	 * @param rs
	 * @throws Exception
	 */
	private void createIndex3(ResultSet rs) throws Exception {
		Directory directory = null;
		IndexWriter indexWriter = null;

		try {
			indexFile = new File(searchDir3);
			if (!indexFile.exists()) {
				indexFile.mkdir();
			}
			directory = FSDirectory.open(indexFile);
			analyzer = new PaodingAnalyzer();

			IndexWriterConfig iwc = new IndexWriterConfig(Version.LUCENE_44,
					analyzer);
			indexWriter = new IndexWriter(directory, iwc);

			Document doc = null;
			while (rs.next()) {
				doc = new Document();
				Field id = new StringField("id", rs.getLong("id") + "",
						Field.Store.YES);
				Field detail = new TextField("detail", rs.getString("detail"),
						Field.Store.YES);
				Field user_name = new StringField("user_name",
						rs.getString("user_name"), Field.Store.YES);
				Field link = new StringField("link", rs.getString("link"),
						Field.Store.YES);
				Field time = new StringField("time", formatter.format(rs
						.getDate("time")), Field.Store.YES);

				doc.add(id);
				doc.add(detail);
				doc.add(user_name);
				doc.add(link);
				doc.add(time);
				indexWriter.addDocument(doc);
			}

			indexWriter.close();
			directory.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
