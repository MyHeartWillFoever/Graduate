package cn.ssms.search;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import net.paoding.analysis.analyzer.PaodingAnalyzer;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.junit.Test;

import com.boge.AnswersWithBLOBs;

import cn.ssms.util.SystemConstant;

/**
 * 获得索引查询结果
 */
public class GetSearchResult {

	public static int eachePageNum = 8;//每页显示的个数
	private Directory directory;
	private DirectoryReader reader;
	private String searchDir = "E:\\Test\\Index";
	private static File indexFile = null;
	private static IndexSearcher searcher = null;
	private SimpleDateFormat formatter = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");
	
	/**
	 * 
	 * @return
	 * @throws IOException 
	 */
	public IndexSearcher getSearcher() throws IOException{
		try {
			if(reader == null){
				reader = DirectoryReader.open(directory);
			}else{
				DirectoryReader tr = DirectoryReader.openIfChanged(reader);
				if(tr != null){
					reader.close();
					reader = tr;
				}
			}
			return new IndexSearcher(reader);
		} catch (CorruptIndexException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * 获取ScoreDoc
	 * @param queryStr
	 * @param headSearchNum 得到查询的靠前的结果数
	 * @return
	 * @throws Exception
	 */
	public ScoreDoc[] getScoreDocs(String queryStr, int headSearchNum)
			throws Exception {
		directory = FSDirectory.open(new File(searchDir));//打开回答数据库对应的索引文件夹
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);//定义索引搜索
		Query query = this.getQuery(queryStr, headSearchNum);//调用搜索函数，得到搜索对象，结果便在其中
		TopDocs topDocs = searcher.search(query, headSearchNum);//搜索靠前的结果
		ScoreDoc[] hits = topDocs.scoreDocs;//得到ScoreDoc数组
		return hits;//返回结果
	}
	
	/**
	 * 获得查询
	 * @param queryStr
	 * @param headSearchNum
	 * @return
	 * @throws Exception
	 */
	public Query getQuery(String queryStr, int headSearchNum) throws Exception {
		PaodingAnalyzer analyzer = new PaodingAnalyzer();//定义PaodingAnalyzer对象，供下面使用
		String field = "answer";//定义需要查询哪个数据库字段
		QueryParser parser = new QueryParser(Version.LUCENE_44, field, analyzer);//得到查询解析对象
		Query query = parser.parse(queryStr);//执行查询，并返回
		return query;//返回结果
	}
	
	/**
	 * 获得索引结果
	 * @param queryStr
	 * @param currentPageNum
	 * @param topNum
	 * @return
	 * @throws Exception
	 */
	public List<AnswersWithBLOBs> getResult(String queryStr, int currentPageNum,int topNum)
			throws Exception {
		//初始化列表
		List<AnswersWithBLOBs> list = new ArrayList<AnswersWithBLOBs>();
		directory = FSDirectory.open(new File(searchDir));//打开索引文件夹
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);
		//高亮显示设置
		Highlighter highlighter = null;
		SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter("<font color='red'><b>", "</b></font>");
		Highlighter highlighterTitle = null;
		SimpleHTMLFormatter formatTitle = new SimpleHTMLFormatter("<FONT color=#c60a00>", "</FONT>");
		ScoreDoc[] hits = this.getScoreDocs(queryStr, topNum);
		Query query = this.getQuery(queryStr, topNum);//获得查询
		highlighter = new Highlighter(simpleHTMLFormatter, new QueryScorer(query));
		highlighterTitle = new Highlighter(formatTitle, new QueryScorer(query));
		highlighter.setTextFragmenter(new SimpleFragmenter(200));//这个200是指定关键字字符串的context
		//的长度，你可以自己设定，因为不可能返回整篇正文内容
		Document doc;
        String fileName="";
		int totalNumber = currentPageNum * eachePageNum;
		if (totalNumber > hits.length)
			totalNumber = hits.length;
		for (int i = (currentPageNum - 1) * eachePageNum; i < totalNumber; i++) {//返回当前页的内容
			//打印文档的内容
			doc = searcher.doc(hits[i].doc);
			//高亮出显示
			AnswersWithBLOBs answersWithBLOBs = new AnswersWithBLOBs();
			TokenStream tokenStream = new PaodingAnalyzer().tokenStream("answer", new StringReader(doc.get("answer")));
			answersWithBLOBs.setAnswer(highlighter.getBestFragment(tokenStream, doc.get("answer")));
			fileName = doc.get("question");
			tokenStream = new PaodingAnalyzer().tokenStream("question",new StringReader(fileName));
			//需要注意：在处理时如果文本检索结果中不包含对应的关键字返回一个null
			String forMatt=highlighterTitle.getBestFragment(tokenStream, fileName);
			if(forMatt == null){
				answersWithBLOBs.setQuestion(fileName);
			}else{
				answersWithBLOBs.setQuestion(forMatt);
			}
			answersWithBLOBs.setId(Long.parseLong(doc.get("id")));
			answersWithBLOBs.setLink(doc.get("link"));//在前端中设置链接，点击后会跳转到该链接，该链接是原网页的地址
			list.add(answersWithBLOBs);
		}
		return list;
	}
	@Test
	public  void test1()throws Exception{
		System.out.println(this.getResult("挖掘", 2,200));
	}
}
