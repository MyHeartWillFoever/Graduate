package cn.ssms.search;

import java.io.File;
import java.io.StringReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import net.paoding.analysis.analyzer.PaodingAnalyzer;

import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import com.boge.AnswersWithBLOBs;
import com.boge.QuestionsWithBLOBs;
import com.boge.UsersWithBLOBs;

import cn.ssms.util.SystemConstant;

/**
 * 高级搜索
 */
public class AdvanceGetSearchResult {
	private Directory directory;
	private DirectoryReader reader;
	private String queryStr;
	private int eachePageNum = 10;// 每页显示的个数
	private String docType;
	private String qtype;
	private int totalNum = 100;

	/* 知乎答案 */
	private String searchDir = "E:\\Test\\Index";
	private String searchDir2 = "E:\\Test\\Index2";// 知乎提问
	private String searchDir3 = "E:\\Test\\Index3";// 知乎用户
	private static File indexFile = null;
	private static IndexSearcher searcher = null;
	private SimpleDateFormat formatter = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss");

	public AdvanceGetSearchResult(int eachePageNum, String docType,
			String qtype, String queryStr, int totalNum) {
		this.eachePageNum = eachePageNum;
		this.docType = docType;
		this.qtype = qtype;
		this.queryStr = queryStr;
		this.totalNum = totalNum;
	}

	/**
	 * 
	 * @param queryStr
	 * @param headSearchNum
	 *            得到查询的靠前的结果数
	 * @return
	 * @throws Exception
	 */
	public ScoreDoc[] getScoreDocs() throws Exception {
		directory = FSDirectory.open(new File(searchDir));
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);
		Query query = this.getQuery();
		TopDocs topDocs = searcher.search(query, this.totalNum);
		ScoreDoc[] hits = topDocs.scoreDocs;
		return hits;
	}

	/**
	 * 
	 * @param queryStr
	 * @param headSearchNum
	 *            得到查询的靠前的结果数
	 * @return
	 * @throws Exception
	 */
	public ScoreDoc[] getScoreDocs2() throws Exception {
		directory = FSDirectory.open(new File(searchDir2));
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);
		Query query = this.getQuery2();
		TopDocs topDocs = searcher.search(query, this.totalNum);
		ScoreDoc[] hits = topDocs.scoreDocs;
		return hits;
	}

	/**
	 * 
	 * @param queryStr
	 * @param headSearchNum
	 *            得到查询的靠前的结果数
	 * @return
	 * @throws Exception
	 */
	public ScoreDoc[] getScoreDocs3() throws Exception {
		directory = FSDirectory.open(new File(searchDir3));
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);
		Query query = this.getQuery3();
		TopDocs topDocs = searcher.search(query, this.totalNum);
		ScoreDoc[] hits = topDocs.scoreDocs;
		return hits;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public Query getQuery() throws Exception {
		PaodingAnalyzer analyzer = new PaodingAnalyzer();
		String field = "answer";
		Query query = null;

		BooleanQuery booleanQuery = new BooleanQuery();

		if (this.qtype.equals("term")) {
			QueryParser parser = new QueryParser(Version.LUCENE_44, field,
					analyzer);
			query = parser.parse(queryStr);

		} else if ("fuzz".equals(this.qtype)) {
			Term term = new Term(field, queryStr);
			query = new FuzzyQuery(term);
		} else {
			Term term = new Term(field, queryStr);
			query = new PrefixQuery(term);
		}
		/*
		 * if (!"all".equals(this.docType)) { Term typeTerm = new Term("type",
		 * this.docType); TermQuery typeQuery = new TermQuery(typeTerm);
		 * booleanQuery.add(typeQuery, BooleanClause.Occur.MUST); }
		 */

		// System.out.println("--this.docType---"+this.docType);
		booleanQuery.add(query, BooleanClause.Occur.MUST);

		return booleanQuery;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public Query getQuery2() throws Exception {
		PaodingAnalyzer analyzer = new PaodingAnalyzer();
		String field = "detail";
		Query query = null;

		BooleanQuery booleanQuery = new BooleanQuery();

		if (this.qtype.equals("term")) {
			QueryParser parser = new QueryParser(Version.LUCENE_44, field,
					analyzer);
			query = parser.parse(queryStr);

		} else if ("fuzz".equals(this.qtype)) {
			Term term = new Term(field, queryStr);
			query = new FuzzyQuery(term);
		} else {
			Term term = new Term(field, queryStr);
			query = new PrefixQuery(term);
		}
		/*
		 * if (!"all".equals(this.docType)) { Term typeTerm = new Term("type",
		 * this.docType); TermQuery typeQuery = new TermQuery(typeTerm);
		 * booleanQuery.add(typeQuery, BooleanClause.Occur.MUST); }
		 */

		// System.out.println("--this.docType---"+this.docType);
		booleanQuery.add(query, BooleanClause.Occur.MUST);

		return booleanQuery;
	}

	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public Query getQuery3() throws Exception {
		PaodingAnalyzer analyzer = new PaodingAnalyzer();
		String field = "user_name";
		Query query = null;

		BooleanQuery booleanQuery = new BooleanQuery();

		if (this.qtype.equals("term")) {
			QueryParser parser = new QueryParser(Version.LUCENE_44, field,
					analyzer);
			query = parser.parse(queryStr);

		} else if ("fuzz".equals(this.qtype)) {
			Term term = new Term(field, queryStr);
			query = new FuzzyQuery(term);
		} else {
			Term term = new Term(field, queryStr);
			query = new PrefixQuery(term);
		}
		/*
		 * if (!"all".equals(this.docType)) { Term typeTerm = new Term("type",
		 * this.docType); TermQuery typeQuery = new TermQuery(typeTerm);
		 * booleanQuery.add(typeQuery, BooleanClause.Occur.MUST); }
		 */

		// System.out.println("--this.docType---"+this.docType);
		booleanQuery.add(query, BooleanClause.Occur.MUST);

		return booleanQuery;
	}

	/**
	 * 知乎答案
	 * 
	 * @param currentPageNum
	 * @return
	 * @throws Exception
	 */
	public List<AnswersWithBLOBs> getResult(int currentPageNum)
			throws Exception {

		List<AnswersWithBLOBs> list = new ArrayList<AnswersWithBLOBs>();
		directory = FSDirectory.open(new File(searchDir));
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);

		// 高亮显示设置
		Highlighter highlighter = null;

		SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter(
				"<font color='red'><b>", "</b></font>");

		Highlighter highlighterTitle = null;

		SimpleHTMLFormatter formatTitle = new SimpleHTMLFormatter(
				"<FONT color=#c60a00>", "</FONT>");

		ScoreDoc[] hits = this.getScoreDocs();
		Query query = this.getQuery();
		highlighter = new Highlighter(simpleHTMLFormatter, new QueryScorer(
				query));
		highlighterTitle = new Highlighter(formatTitle, new QueryScorer(query));
		highlighter.setTextFragmenter(new SimpleFragmenter(200));// 这个200是指定关键字字符串的context
		// 的长度，你可以自己设定，因为不可能返回整篇正文内容
		Document doc;
		String fileName = "";
		int totalNumber = currentPageNum * eachePageNum;
		if (totalNumber > hits.length)
			totalNumber = hits.length;
		for (int i = (currentPageNum - 1) * eachePageNum; i < totalNumber; i++) {

			// 打印文档的内容
			doc = searcher.doc(hits[i].doc);
			// System.out.println(doc.toString());
			// if(this.docType.equals(doc.get("type"))){
			// 高亮出显示
			AnswersWithBLOBs answersWithBLOBs = new AnswersWithBLOBs();
			TokenStream tokenStream = new PaodingAnalyzer().tokenStream(
					"answer", new StringReader(doc.get("answer")));
			answersWithBLOBs.setAnswer(highlighter.getBestFragment(tokenStream,
					doc.get("answer")));
			// System.out.println("----------"+i+"----------");
			// System.out.println(answersWithBLOBs.getContents());
			fileName = doc.get("question");
			tokenStream = new PaodingAnalyzer().tokenStream("question",
					new StringReader(fileName));
			// 需要注意：在处理时如果文本检索结果中不包含对应的关键字返回一个null
			String forMatt = highlighterTitle.getBestFragment(tokenStream,
					fileName);
			if (forMatt == null)
				answersWithBLOBs.setQuestion(fileName);
			else
				answersWithBLOBs.setQuestion(forMatt);

			answersWithBLOBs.setId(Long.parseLong(doc.get("id")));
			answersWithBLOBs.setLink(doc.get("link"));

			list.add(answersWithBLOBs);
		}// end for
		return list;
	}

	/**
	 * 知乎提问
	 * 
	 * @param currentPageNum
	 * @return
	 * @throws Exception
	 */
	public List<QuestionsWithBLOBs> getResult2(int currentPageNum)
			throws Exception {

		List<QuestionsWithBLOBs> list = new ArrayList<QuestionsWithBLOBs>();
		directory = FSDirectory.open(new File(searchDir2));
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);

		// 高亮显示设置
		Highlighter highlighter = null;

		SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter(
				"<font color='red'><b>", "</b></font>");

		Highlighter highlighterTitle = null;

		SimpleHTMLFormatter formatTitle = new SimpleHTMLFormatter(
				"<FONT color=#c60a00>", "</FONT>");

		ScoreDoc[] hits = this.getScoreDocs2();
		System.out.println("hits "+hits.length);
		Query query = this.getQuery2();
		highlighter = new Highlighter(simpleHTMLFormatter, new QueryScorer(
				query));
		highlighterTitle = new Highlighter(formatTitle, new QueryScorer(query));
		highlighter.setTextFragmenter(new SimpleFragmenter(200));// 这个200是指定关键字字符串的context
		// 的长度，你可以自己设定，因为不可能返回整篇正文内容
		Document doc;
		String fileName = "";
		int totalNumber = currentPageNum * eachePageNum;
		if (totalNumber > hits.length)
			totalNumber = hits.length;
		System.out.println(totalNumber);
		for (int i = (currentPageNum - 1) * eachePageNum; i < totalNumber; i++) {

			// 打印文档的内容
			doc = searcher.doc(hits[i].doc);
			// System.out.println(doc.toString());
			// if(this.docType.equals(doc.get("type"))){
			// 高亮出显示
			QuestionsWithBLOBs answersWithBLOBs = new QuestionsWithBLOBs();
			TokenStream tokenStream = new PaodingAnalyzer().tokenStream(
					"detail", new StringReader(doc.get("detail")));
			answersWithBLOBs.setDetail(highlighter.getBestFragment(tokenStream,
					doc.get("detail")));
			// System.out.println("----------"+i+"----------");
			// System.out.println(answersWithBLOBs.getContents());
			fileName = doc.get("question");
			tokenStream = new PaodingAnalyzer().tokenStream("question",
					new StringReader(fileName));
			// 需要注意：在处理时如果文本检索结果中不包含对应的关键字返回一个null
			String forMatt = highlighterTitle.getBestFragment(tokenStream,
					fileName);
			if (forMatt == null)
				answersWithBLOBs.setQuestion(fileName);
			else
				answersWithBLOBs.setQuestion(forMatt);

			answersWithBLOBs.setId(Long.parseLong(doc.get("id")));
			answersWithBLOBs.setLink(doc.get("link"));

			list.add(answersWithBLOBs);
		}// end for
		return list;
	}

	/**
	 * 知乎用户
	 * 
	 * @param currentPageNum
	 * @return
	 * @throws Exception
	 */
	public List<UsersWithBLOBs> getResult3(int currentPageNum) throws Exception {

		List<UsersWithBLOBs> list = new ArrayList<UsersWithBLOBs>();
		directory = FSDirectory.open(new File(searchDir3));
		reader = DirectoryReader.open(directory);
		IndexSearcher searcher = new IndexSearcher(reader);

		// 高亮显示设置
		Highlighter highlighter = null;

		SimpleHTMLFormatter simpleHTMLFormatter = new SimpleHTMLFormatter(
				"<font color='red'><b>", "</b></font>");

		Highlighter highlighterTitle = null;

		SimpleHTMLFormatter formatTitle = new SimpleHTMLFormatter(
				"<FONT color=#c60a00>", "</FONT>");

		ScoreDoc[] hits = this.getScoreDocs3();
		Query query = this.getQuery3();
		highlighter = new Highlighter(simpleHTMLFormatter, new QueryScorer(
				query));
		highlighterTitle = new Highlighter(formatTitle, new QueryScorer(query));
		highlighter.setTextFragmenter(new SimpleFragmenter(200));// 这个200是指定关键字字符串的context
		// 的长度，你可以自己设定，因为不可能返回整篇正文内容
		Document doc;
		String fileName = "";
		int totalNumber = currentPageNum * eachePageNum;
		if (totalNumber > hits.length)
			totalNumber = hits.length;
		for (int i = (currentPageNum - 1) * eachePageNum; i < totalNumber; i++) {

			// 打印文档的内容
			doc = searcher.doc(hits[i].doc);
			// System.out.println(doc.toString());
			// if(this.docType.equals(doc.get("type"))){
			// 高亮出显示
			UsersWithBLOBs answersWithBLOBs = new UsersWithBLOBs();
			TokenStream tokenStream = new PaodingAnalyzer().tokenStream(
					"user_name", new StringReader(doc.get("user_name")));
			answersWithBLOBs.setDetail(highlighter.getBestFragment(tokenStream,
					doc.get("user_name")));
			// System.out.println("----------"+i+"----------");
			// System.out.println(answersWithBLOBs.getContents());
			fileName = doc.get("detail");
			tokenStream = new PaodingAnalyzer().tokenStream("detail",
					new StringReader(fileName));
			// 需要注意：在处理时如果文本检索结果中不包含对应的关键字返回一个null
			String forMatt = highlighterTitle.getBestFragment(tokenStream,
					fileName);
			if (forMatt == null)
				answersWithBLOBs.setUserName(fileName);
			else
				answersWithBLOBs.setUserName(forMatt);

			answersWithBLOBs.setId(Long.parseLong(doc.get("id")));
			answersWithBLOBs.setLink(doc.get("link"));

			list.add(answersWithBLOBs);
		}// end for
		return list;
	}
}
