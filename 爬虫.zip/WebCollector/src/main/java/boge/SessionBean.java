package boge;

import java.io.Reader;

import javax.swing.JOptionPane;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SessionBean {
	private static SqlSession session = null;
	public static SqlSession getSession() {
		/*若session不为null。则直接返回*/
		if(session != null){
			return session;
		}
		Reader reader = null;
		SqlSessionFactory sf = null;
		try {
			/*读取配置文件，连接数据库*/
			reader = Resources.getResourceAsReader("com/config/mybatis.xml");
			sf = new SqlSessionFactoryBuilder().build(reader);
			session = sf.openSession(true);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null,"网络连接错误！！！");
		}
		return session;
	}
}
