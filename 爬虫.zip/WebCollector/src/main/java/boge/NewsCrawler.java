package boge;

import java.util.Date;
import java.util.regex.Pattern;

import org.apache.ibatis.session.SqlSession;
import org.jsoup.select.Elements;

import com.pojo.AnswersMapper;
import com.pojo.AnswersWithBLOBs;
import com.pojo.QuestionsMapper;
import com.pojo.QuestionsWithBLOBs;
import com.pojo.UsersMapper;
import com.pojo.UsersWithBLOBs;

import cn.edu.hfut.dmic.webcollector.model.CrawlDatums;
import cn.edu.hfut.dmic.webcollector.model.Page;
import cn.edu.hfut.dmic.webcollector.plugin.berkeley.BreadthCrawler;

/**
 * Crawling news from hfut news
 *
 * @author hu
 */
public class NewsCrawler extends BreadthCrawler {

	/*获取session，用于对数据库的操作*/
	private static SqlSession session = SessionBean.getSession();

	/**
	 * @param crawlPath
	 *            crawlPath is the path of the directory which maintains
	 *            information of this crawler
	 * @param autoParse
	 *            if autoParse is true,BreadthCrawler will auto extract links
	 *            which match regex rules from pag
	 */
	public NewsCrawler(String crawlPath, boolean autoParse) {
		super(crawlPath, autoParse);
	}

	@Override
	public void visit(Page page, CrawlDatums next) {
		/*待处理的网址要满足以下两个正则表达式其中之一，否则不予处理*/
		String question_regex2 = "^http://www.zhihu.com/people/.*";
		String question_regex = "^http://www.zhihu.com/question/\\d+$";

		/*知乎提问和知乎回答处理*/
		if (Pattern.matches(question_regex, page.getUrl())) {
			System.out.println("正在抽取" + page.getUrl());
			/*当前处理的网址*/
			String link = page.getUrl();
			System.out.println("链接： " + link);
			/* 抽取标题 */
			String title = page.getDoc().title();
			boolean flag = false;
			if (title.lastIndexOf(" - 知乎") > 0
					&& title.lastIndexOf(" - 知乎") < title.length()) {
				title = title.substring(0, title.lastIndexOf(" - 知乎"));
				flag = true;
			}
			if (flag && title.lastIndexOf("-") > 0
					&& title.lastIndexOf("-") < title.length()) {
				title = title.substring(0, title.lastIndexOf("-") - 1);
			}
			System.out.println("title: " + title);
			/* 抽取提问内容 */
			Elements el = page.getDoc().select("div[id=zh-question-detail]");
			String question = "";
			if (el != null) {
				question = el.text();
			}
			System.out.println("question: " + question);
			/*将抽取到的提问及描述存入数据库*/
			if (session != null) {
				QuestionsMapper questionsMapper = session
						.getMapper(QuestionsMapper.class);
				QuestionsWithBLOBs questions = new QuestionsWithBLOBs();
				questions.setLink(page.getUrl());
				questions.setDetail(question);
				questions.setQuestion(title);
				questions.setTime(new Date());
				questionsMapper.insert(questions);
			}
			// 匹配答案
			Object[] os = null;
			Elements el2 = page.getDoc().select(
					"div[class=zm-editable-content clearfix]");
			if (el2 != null) {
				os = el2.toArray();
			}
			for (int i = 0; os != null && i < os.length; i++) {
				System.out.print("答案" + (i + 1) + " : ");
				System.out.println(os[i].toString().replaceAll("<.*?>", "")
						.trim());
			}
			System.out.println();
			Elements el3 = page.getDoc().select("div[data-entry-url]");
			if (el3 != null) {
				for (int i = 0; i < el3.size(); i++) {
					System.out.print("答案" + (i + 1) + "链接 : ");
					System.out.println("http://www.zhihu.com"
							+ el3.get(i).attr("data-entry-url"));
				}
			}
			/*将知乎回答存入数据库*/
			if (session != null) {
				AnswersMapper answersMapper = session
						.getMapper(AnswersMapper.class);
				for (int i = 0; i < os.length && i < el3.size(); i++) {
					AnswersWithBLOBs answers = new AnswersWithBLOBs();
					answers.setQuestion(title);
					answers.setLink("http://www.zhihu.com"
							+ el3.get(i).attr("data-entry-url"));
					answers.setAnswer(os[i].toString().replaceAll("<.*?>", "")
							.trim());
					answers.setTime(new Date());
					answersMapper.insert(answers);
				}
			}

		} else if (Pattern.matches(question_regex2, page.getUrl())) {
			System.out.println("正在抽取" + page.getUrl());
			/* 抽取标题 */
			String name = page.getDoc().title();
			name = name.substring(0, name.indexOf("-") - 1).trim();
			String link = page.getUrl();
			System.out.println("链接： " + link);
			System.out.println("name: " + name);
			/* 抽取提问内容 */
			Elements el = page.getDoc().select(
					"[id=profile-header-description-input]");
			String details = "";
			if (el != null) {
				details = el.text();
			}
			System.out.println("details: " + details);
			/*将用户信息存入数据库*/
			if (session != null) {
				UsersMapper usersMapper = session
						.getMapper(UsersMapper.class);
				UsersWithBLOBs users = new UsersWithBLOBs();
				users.setUserName(name);
				users.setLink(link);
				users.setDetail(details);
				users.setTime(new Date());
				usersMapper.insert(users);
			}
		}else {
			/*不予处理，将不满足正则表达式的网址打印输出到控制台*/
			System.out.println("**********    "+page.getUrl());
		}
	}
}